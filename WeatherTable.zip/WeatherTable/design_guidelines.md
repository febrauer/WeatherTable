# Weather Forecast Dashboard Design Guidelines

## Design Approach

**Selected Approach:** Design System (Material Design) + Modern Dashboard Aesthetics (Linear/Notion-inspired)

**Justification:** This is a utility-focused, data-heavy application where efficiency, clarity, and usability are paramount. Material Design provides excellent patterns for tables and data visualization, while Linear/Notion's clean aesthetic ensures modern appeal.

**Core Principles:**
- Data clarity over decoration
- Instant visual feedback through color coding
- Scannable tables with clear hierarchy
- Efficient threshold controls
- Minimal cognitive load

## Color Palette

**Dark Mode Primary (Default):**
- Background: 220 15% 12% (deep slate)
- Surface: 220 14% 16% (elevated cards)
- Surface Elevated: 220 13% 20% (table headers)
- Text Primary: 0 0% 95%
- Text Secondary: 220 8% 65%
- Border: 220 10% 25%

**Threshold States:**
- Exceeds Maximum: 0 84% 45% (vibrant red for warnings)
- Below Minimum: 217 91% 50% (electric blue for cold/low values)
- Normal: inherit (no special highlighting)
- Warning Background: 0 84% 45% at 12% opacity
- Low Background: 217 91% 50% at 12% opacity

**Accent Colors:**
- Primary Action: 217 91% 60% (bright blue)
- Success/Update: 142 71% 45% (green for data refresh)

## Typography

**Font Families:**
- Primary: 'Inter', system-ui, sans-serif (for UI and data)
- Monospace: 'JetBrains Mono', 'Fira Code', monospace (for numerical values)

**Type Scale:**
- Dashboard Title: text-2xl font-semibold (24px)
- Section Headers: text-lg font-medium (18px)
- Parameter Names: text-sm font-medium (14px)
- Table Headers: text-xs font-semibold uppercase tracking-wide (12px)
- Data Values: text-sm font-mono (14px monospace)
- Helper Text: text-xs text-secondary (12px)

## Layout System

**Spacing Primitives:** Use Tailwind units of 2, 4, 6, 8, 12, 16 for consistency
- Component padding: p-6 or p-8
- Section gaps: gap-6 or gap-8
- Table cell padding: p-4
- Input controls: p-3

**Container Strategy:**
- Full-width dashboard with max-w-screen-2xl mx-auto
- Two-column layout on large screens: Sidebar (controls) + Main (tables)
- Stack vertically on mobile/tablet

## Component Library

### Dashboard Header
- App title with weather location indicator
- Last updated timestamp
- Refresh data button (with loading state)
- Compact, sticky on scroll

### Threshold Control Panel
- Collapsible sidebar (desktop) or accordion (mobile)
- Each parameter has: Parameter name, min input, max input, reset button
- Number inputs with +/- steppers
- Visual indicator showing current threshold range
- Apply changes instantly (no submit button needed)

### Master Weather Table
- Sticky header row
- Sortable columns (click header to sort)
- Alternating row backgrounds for scannability
- Compact row height (not too spacious)
- Horizontal scroll on mobile
- Color-coded cells based on active thresholds

### Individual Parameter Tables
- Tabbed interface or accordion sections
- Each tab shows: Time, Value, Status (normal/warning/low)
- Sparkline visualization alongside table
- Export data button for each table

### Data Cells
- Numeric values right-aligned in monospace font
- Threshold-exceeded cells: colored background with bold text
- Units displayed in muted color next to values
- Hover state shows exact timestamp

### Input Controls
- Outlined style with focus rings
- Clear labels above inputs
- Placeholder showing current min/max
- Validation indicators (red border for invalid ranges)

### Cards/Surfaces
- Subtle rounded corners (rounded-lg)
- Soft shadows for elevation (shadow-md)
- Border treatment for definition

## Interactions

**Threshold Highlighting:**
- Smooth color transition (150ms) when threshold values change
- Pulse animation briefly when new data loads
- Subtle hover state on table rows (background lightens 3%)

**Data Refresh:**
- Loading skeleton for tables during fetch
- Success toast notification on update
- Auto-refresh toggle with interval selector

**Responsive Behavior:**
- Desktop: Side-by-side controls + tables
- Tablet: Stacked with collapsible control panel
- Mobile: Full-width tables with horizontal scroll, bottom sheet controls

## Accessibility

- High contrast ratios for all text (WCAG AAA)
- Keyboard navigation for threshold inputs
- Focus visible states on all interactive elements
- Screen reader labels for data cells
- Color coding supplemented with icons (✓ ⚠ ❄)

## Visual Hierarchy

1. **Primary:** Current threshold violations (colored backgrounds)
2. **Secondary:** Table headers and parameter names
3. **Tertiary:** Normal data values
4. **Quaternary:** Timestamps, units, helper text

## Images

**No hero images required** - This is a data dashboard focused on functionality.