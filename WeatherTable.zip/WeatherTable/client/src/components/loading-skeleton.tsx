import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

export function LoadingSkeleton() {
  return (
    <div className="space-y-6">
      <Card className="overflow-hidden">
        <div className="p-4 border-b">
          <Skeleton className="h-6 w-32" />
        </div>
        <div className="overflow-x-auto">
          <div className="min-w-full">
            <div className="flex border-b">
              <Skeleton className="h-12 w-40 m-2" />
              {Array.from({ length: 8 }).map((_, i) => (
                <Skeleton key={i} className="h-12 w-32 m-2" />
              ))}
            </div>
            {Array.from({ length: 10 }).map((_, rowIdx) => (
              <div key={rowIdx} className="flex border-b">
                <Skeleton className="h-10 w-40 m-2" />
                {Array.from({ length: 8 }).map((_, cellIdx) => (
                  <Skeleton key={cellIdx} className="h-10 w-32 m-2" />
                ))}
              </div>
            ))}
          </div>
        </div>
      </Card>
    </div>
  );
}
