import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { weatherParameters } from "@shared/schema";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";

interface ParameterTabsProps {
  value: string;
  onValueChange: (value: string) => void;
  children: React.ReactNode;
}

export function ParameterTabs({ value, onValueChange, children }: ParameterTabsProps) {
  return (
    <Tabs value={value} onValueChange={onValueChange} className="space-y-6">
      <ScrollArea className="w-full">
        <TabsList className="inline-flex h-auto p-1 gap-1">
          <TabsTrigger 
            value="all" 
            className="text-xs px-3 py-2"
            data-testid="tab-all-parameters"
          >
            All Parameters
          </TabsTrigger>
          {weatherParameters.map((param) => (
            <TabsTrigger
              key={param.key}
              value={param.key}
              className="text-xs px-3 py-2"
              data-testid={`tab-${param.key}`}
            >
              {param.label}
            </TabsTrigger>
          ))}
        </TabsList>
        <ScrollBar orientation="horizontal" />
      </ScrollArea>

      <TabsContent value="all" className="space-y-0 mt-6">
        {children}
      </TabsContent>
      
      {weatherParameters.map((param) => (
        <TabsContent key={param.key} value={param.key} className="space-y-0 mt-6">
          {children}
        </TabsContent>
      ))}
    </Tabs>
  );
}
