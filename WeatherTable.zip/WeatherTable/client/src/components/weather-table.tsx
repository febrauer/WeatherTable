import { useMemo, useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card } from "@/components/ui/card";
import { ArrowUpDown, ArrowUp, ArrowDown, AlertTriangle, Snowflake } from "lucide-react";
import { Button } from "@/components/ui/button";
import { HourlyDataRow, ThresholdState, weatherParameters } from "@shared/schema";
import { cn } from "@/lib/utils";

interface WeatherTableProps {
  data: HourlyDataRow[];
  thresholds: ThresholdState;
  selectedParameter?: string;
}

type SortDirection = 'asc' | 'desc' | null;

export function WeatherTable({ data, thresholds, selectedParameter }: WeatherTableProps) {
  const [sortColumn, setSortColumn] = useState<string | null>(null);
  const [sortDirection, setSortDirection] = useState<SortDirection>(null);

  const visibleParameters = useMemo(() => {
    if (selectedParameter) {
      return weatherParameters.filter(p => p.key === selectedParameter);
    }
    return weatherParameters;
  }, [selectedParameter]);

  const handleSort = (column: string) => {
    if (sortColumn === column) {
      if (sortDirection === 'asc') {
        setSortDirection('desc');
      } else if (sortDirection === 'desc') {
        setSortColumn(null);
        setSortDirection(null);
      }
    } else {
      setSortColumn(column);
      setSortDirection('asc');
    }
  };

  const sortedData = useMemo(() => {
    if (!sortColumn || !sortDirection) return data;

    return [...data].sort((a, b) => {
      const aVal = a[sortColumn];
      const bVal = b[sortColumn];
      
      if (aVal === null || aVal === undefined) return 1;
      if (bVal === null || bVal === undefined) return -1;
      
      // Special handling for time column - parse as Date objects with validation
      if (sortColumn === 'time') {
        const timeA = new Date(aVal as string).getTime();
        const timeB = new Date(bVal as string).getTime();
        
        // Handle invalid dates (NaN) by pushing them to the end
        if (isNaN(timeA) && isNaN(timeB)) return 0;
        if (isNaN(timeA)) return 1;
        if (isNaN(timeB)) return -1;
        
        return sortDirection === 'asc' ? timeA - timeB : timeB - timeA;
      }
      
      // For numeric columns, parse as numbers
      const numA = typeof aVal === 'number' ? aVal : parseFloat(aVal as string);
      const numB = typeof bVal === 'number' ? bVal : parseFloat(bVal as string);
      
      // Handle NaN values by pushing them to the end
      if (isNaN(numA) && isNaN(numB)) return 0;
      if (isNaN(numA)) return 1;
      if (isNaN(numB)) return -1;
      
      if (sortDirection === 'asc') {
        return numA - numB;
      } else {
        return numB - numA;
      }
    });
  }, [data, sortColumn, sortDirection]);

  const getThresholdStatus = (parameter: string, value: number | null): 'normal' | 'above' | 'below' => {
    if (value === null || value === undefined) return 'normal';
    
    const threshold = thresholds[parameter];
    if (!threshold) return 'normal';

    if (threshold.max !== null && value > threshold.max) return 'above';
    if (threshold.min !== null && value < threshold.min) return 'below';
    
    return 'normal';
  };

  const formatValue = (value: string | number | null): string => {
    if (value === null || value === undefined) return '-';
    if (typeof value === 'number') {
      return value.toFixed(1);
    }
    return value;
  };

  const formatTime = (time: string): string => {
    try {
      const date = new Date(time);
      return date.toLocaleString('en-GB', {
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return time;
    }
  };

  const SortIcon = ({ column }: { column: string }) => {
    if (sortColumn !== column) {
      return <ArrowUpDown className="h-3.5 w-3.5 ml-1 opacity-40" />;
    }
    if (sortDirection === 'asc') {
      return <ArrowUp className="h-3.5 w-3.5 ml-1" />;
    }
    return <ArrowDown className="h-3.5 w-3.5 ml-1" />;
  };

  return (
    <Card className="overflow-hidden">
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="hover:bg-transparent">
              <TableHead className="sticky left-0 z-10 bg-card min-w-[140px]">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleSort('time')}
                  className="h-auto p-0 hover:bg-transparent font-semibold text-xs uppercase tracking-wide"
                  data-testid="button-sort-time"
                >
                  Time
                  <SortIcon column="time" />
                </Button>
              </TableHead>
              {visibleParameters.map((param) => (
                <TableHead key={param.key} className="text-center min-w-[120px]">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleSort(param.key)}
                    className="h-auto p-0 hover:bg-transparent font-semibold text-xs uppercase tracking-wide w-full justify-center"
                    data-testid={`button-sort-${param.key}`}
                  >
                    <span className="flex flex-col items-center gap-0.5">
                      <span>{param.label}</span>
                      {param.unit && (
                        <span className="text-[10px] text-muted-foreground font-normal">
                          ({param.unit})
                        </span>
                      )}
                    </span>
                    <SortIcon column={param.key} />
                  </Button>
                </TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {sortedData.map((row, idx) => (
              <TableRow key={idx} className="hover-elevate" data-testid={`row-weather-${idx}`}>
                <TableCell className="sticky left-0 z-10 bg-card font-medium text-sm">
                  {formatTime(row.time)}
                </TableCell>
                {visibleParameters.map((param) => {
                  const value = row[param.key] as number | null;
                  const status = getThresholdStatus(param.key, value);
                  
                  return (
                    <TableCell
                      key={param.key}
                      className={cn(
                        "text-center font-mono text-sm tabular-nums transition-colors",
                        status === 'above' && "bg-destructive/12 text-destructive font-semibold",
                        status === 'below' && "bg-chart-1/12 text-chart-1 font-semibold"
                      )}
                      data-testid={`cell-${param.key}-${idx}`}
                    >
                      <div className="flex items-center justify-center gap-1.5">
                        {status === 'above' && <AlertTriangle className="h-3.5 w-3.5" />}
                        {status === 'below' && <Snowflake className="h-3.5 w-3.5" />}
                        <span>{formatValue(value)}</span>
                      </div>
                    </TableCell>
                  );
                })}
              </TableRow>
            ))}
            {sortedData.length === 0 && (
              <TableRow>
                <TableCell
                  colSpan={visibleParameters.length + 1}
                  className="text-center text-muted-foreground py-12"
                >
                  No data available
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </Card>
  );
}
