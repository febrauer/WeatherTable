import { useState, useRef, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, MapPin, Loader2, X } from "lucide-react";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import type { Location } from "@shared/schema";

interface LocationSearchProps {
  currentLocation: Location;
  onLocationChange: (location: Location) => void;
}

interface SearchResult {
  place_id: number;
  lat: string;
  lon: string;
  display_name: string;
  address?: {
    city?: string;
    town?: string;
    village?: string;
    state?: string;
    country?: string;
  };
}

export function LocationSearch({ currentLocation, onLocationChange }: LocationSearchProps) {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<SearchResult[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);
  const timeoutRef = useRef<NodeJS.Timeout>();

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowResults(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const searchLocation = async (searchQuery: string) => {
    if (!searchQuery.trim() || searchQuery.length < 2) {
      setResults([]);
      return;
    }

    setIsSearching(true);
    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?` +
        new URLSearchParams({
          q: searchQuery,
          format: 'json',
          limit: '5',
          addressdetails: '1',
        })
      );

      if (!response.ok) {
        throw new Error('Failed to search location');
      }

      const data = await response.json();
      setResults(data);
      setShowResults(true);
    } catch (error) {
      console.error('Location search error:', error);
      setResults([]);
    } finally {
      setIsSearching(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setQuery(value);

    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }

    timeoutRef.current = setTimeout(() => {
      searchLocation(value);
    }, 500);
  };

  const handleSelectLocation = (result: SearchResult) => {
    const locationName = 
      result.address?.city || 
      result.address?.town || 
      result.address?.village || 
      result.display_name.split(',')[0];

    const location: Location = {
      name: locationName,
      latitude: parseFloat(result.lat),
      longitude: parseFloat(result.lon),
      country: result.address?.country,
      state: result.address?.state,
    };

    onLocationChange(location);
    setQuery("");
    setResults([]);
    setShowResults(false);
  };

  const handleClear = () => {
    setQuery("");
    setResults([]);
    setShowResults(false);
  };

  return (
    <div ref={searchRef} className="relative w-full max-w-md">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
        <Input
          type="text"
          placeholder="Search for a location..."
          value={query}
          onChange={handleInputChange}
          onFocus={() => {
            if (results.length > 0) {
              setShowResults(true);
            }
          }}
          className="pl-9 pr-9 h-10"
          data-testid="input-location-search"
        />
        {isSearching && (
          <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 animate-spin text-muted-foreground" />
        )}
        {!isSearching && query && (
          <Button
            variant="ghost"
            size="icon"
            onClick={handleClear}
            className="absolute right-1 top-1/2 -translate-y-1/2 h-7 w-7"
            data-testid="button-clear-search"
          >
            <X className="h-3.5 w-3.5" />
            <span className="sr-only">Clear search</span>
          </Button>
        )}
      </div>

      {showResults && results.length > 0 && (
        <Card className="absolute top-full mt-2 w-full z-50 p-2 max-h-80 overflow-y-auto">
          {results.map((result) => {
            const locationName = 
              result.address?.city || 
              result.address?.town || 
              result.address?.village || 
              result.display_name.split(',')[0];
            
            const region = [result.address?.state, result.address?.country]
              .filter(Boolean)
              .join(', ');

            return (
              <Button
                key={result.place_id}
                variant="ghost"
                className="w-full justify-start text-left h-auto py-3 px-3 hover-elevate"
                onClick={() => handleSelectLocation(result)}
                data-testid={`button-location-${result.place_id}`}
              >
                <MapPin className="h-4 w-4 mr-3 flex-shrink-0 text-primary" />
                <div className="flex-1 min-w-0">
                  <div className="font-medium truncate">{locationName}</div>
                  {region && (
                    <div className="text-sm text-muted-foreground truncate">
                      {region}
                    </div>
                  )}
                </div>
              </Button>
            );
          })}
        </Card>
      )}
    </div>
  );
}
