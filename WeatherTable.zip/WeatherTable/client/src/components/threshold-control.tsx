import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { RotateCcw } from "lucide-react";
import { Card } from "@/components/ui/card";
import { slugify } from "@/lib/utils";

interface ThresholdControlProps {
  label: string;
  unit: string;
  min: number | null;
  max: number | null;
  defaultMin: number;
  defaultMax: number;
  onMinChange: (value: number | null) => void;
  onMaxChange: (value: number | null) => void;
  onReset: () => void;
}

export function ThresholdControl({
  label,
  unit,
  min,
  max,
  defaultMin,
  defaultMax,
  onMinChange,
  onMaxChange,
  onReset,
}: ThresholdControlProps) {
  const slugifiedLabel = slugify(label);
  
  const handleMinChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    onMinChange(value === '' ? null : parseFloat(value));
  };

  const handleMaxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    onMaxChange(value === '' ? null : parseFloat(value));
  };

  const isModified = min !== defaultMin || max !== defaultMax;

  return (
    <Card className="p-4 space-y-3">
      <div className="flex items-center justify-between">
        <h4 className="text-sm font-medium">{label}</h4>
        {isModified && (
          <Button
            variant="ghost"
            size="icon"
            onClick={onReset}
            className="h-7 w-7"
            data-testid={`button-reset-${slugifiedLabel}`}
          >
            <RotateCcw className="h-3.5 w-3.5" />
            <span className="sr-only">Reset thresholds</span>
          </Button>
        )}
      </div>
      
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-2">
          <Label htmlFor={`min-${slugifiedLabel}`} className="text-xs text-muted-foreground uppercase tracking-wide">
            Minimum {unit && `(${unit})`}
          </Label>
          <Input
            id={`min-${slugifiedLabel}`}
            type="number"
            step="any"
            value={min ?? ''}
            onChange={handleMinChange}
            placeholder={defaultMin.toString()}
            className="h-9 font-mono text-sm"
            data-testid={`input-min-${slugifiedLabel}`}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor={`max-${slugifiedLabel}`} className="text-xs text-muted-foreground uppercase tracking-wide">
            Maximum {unit && `(${unit})`}
          </Label>
          <Input
            id={`max-${slugifiedLabel}`}
            type="number"
            step="any"
            value={max ?? ''}
            onChange={handleMaxChange}
            placeholder={defaultMax.toString()}
            className="h-9 font-mono text-sm"
            data-testid={`input-max-${slugifiedLabel}`}
          />
        </div>
      </div>
    </Card>
  );
}
