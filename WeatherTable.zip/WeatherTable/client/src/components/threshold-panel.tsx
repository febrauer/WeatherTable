import { ThresholdControl } from "./threshold-control";
import { weatherParameters, ThresholdState } from "@shared/schema";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Card } from "@/components/ui/card";
import { Sliders } from "lucide-react";

interface ThresholdPanelProps {
  thresholds: ThresholdState;
  onThresholdChange: (parameter: string, min: number | null, max: number | null) => void;
}

export function ThresholdPanel({ thresholds, onThresholdChange }: ThresholdPanelProps) {
  const handleReset = (parameter: string) => {
    const param = weatherParameters.find(p => p.key === parameter);
    if (param) {
      onThresholdChange(parameter, param.defaultMin, param.defaultMax);
    }
  };

  return (
    <Card className="h-full overflow-hidden">
      <div className="p-6 border-b">
        <div className="flex items-center gap-2">
          <Sliders className="h-5 w-5 text-primary" />
          <h2 className="text-lg font-medium">Threshold Controls</h2>
        </div>
        <p className="text-sm text-muted-foreground mt-1">
          Set minimum and maximum thresholds for each parameter
        </p>
      </div>

      <ScrollArea className="h-[calc(100vh-240px)]">
        <div className="p-6 space-y-4">
          {weatherParameters.map((param) => (
            <ThresholdControl
              key={param.key}
              label={param.label}
              unit={param.unit}
              min={thresholds[param.key]?.min ?? param.defaultMin}
              max={thresholds[param.key]?.max ?? param.defaultMax}
              defaultMin={param.defaultMin}
              defaultMax={param.defaultMax}
              onMinChange={(value) => 
                onThresholdChange(param.key, value, thresholds[param.key]?.max ?? param.defaultMax)
              }
              onMaxChange={(value) =>
                onThresholdChange(param.key, thresholds[param.key]?.min ?? param.defaultMin, value)
              }
              onReset={() => handleReset(param.key)}
            />
          ))}
        </div>
      </ScrollArea>
    </Card>
  );
}
