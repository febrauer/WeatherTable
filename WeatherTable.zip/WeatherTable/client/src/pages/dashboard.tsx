import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { DashboardHeader } from "@/components/dashboard-header";
import { ThresholdPanel } from "@/components/threshold-panel";
import { WeatherTable } from "@/components/weather-table";
import { ParameterTabs } from "@/components/parameter-tabs";
import { LoadingSkeleton } from "@/components/loading-skeleton";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";
import { WeatherData, HourlyDataRow, ThresholdState, weatherParameters } from "@shared/schema";

export default function Dashboard() {
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [selectedTab, setSelectedTab] = useState("all");
  
  const [thresholds, setThresholds] = useState<ThresholdState>(() => {
    const initial: ThresholdState = {};
    weatherParameters.forEach(param => {
      initial[param.key] = {
        min: param.defaultMin,
        max: param.defaultMax,
      };
    });
    return initial;
  });

  const { data, isLoading, error, refetch } = useQuery<WeatherData>({
    queryKey: ['/api/weather'],
  });

  const handleRefresh = async () => {
    await refetch();
    setLastUpdated(new Date());
  };

  const handleThresholdChange = (parameter: string, min: number | null, max: number | null) => {
    setThresholds(prev => ({
      ...prev,
      [parameter]: { min, max },
    }));
  };

  const processedData = useMemo<HourlyDataRow[]>(() => {
    if (!data?.hourly) return [];

    const { time, ...parameters } = data.hourly;
    const rows: HourlyDataRow[] = [];

    for (let i = 0; i < time.length; i++) {
      const row: HourlyDataRow = { time: time[i] };
      
      Object.entries(parameters).forEach(([key, values]) => {
        if (values && Array.isArray(values)) {
          row[key] = values[i] ?? null;
        }
      });
      
      rows.push(row);
    }

    return rows;
  }, [data]);

  if (isLoading && !data) {
    return (
      <div className="min-h-screen bg-background">
        <DashboardHeader 
          lastUpdated={lastUpdated} 
          onRefresh={handleRefresh} 
          isLoading={true} 
        />
        <div className="container max-w-screen-2xl mx-auto px-6 py-8">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            <div className="lg:col-span-1">
              <div className="h-[600px] rounded-lg bg-card animate-pulse" />
            </div>
            <div className="lg:col-span-3">
              <LoadingSkeleton />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-background">
        <DashboardHeader 
          lastUpdated={lastUpdated} 
          onRefresh={handleRefresh} 
          isLoading={isLoading} 
        />
        <div className="container max-w-screen-2xl mx-auto px-6 py-8">
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error loading weather data</AlertTitle>
            <AlertDescription>
              {error instanceof Error ? error.message : 'Failed to fetch weather forecast. Please try again.'}
            </AlertDescription>
          </Alert>
        </div>
      </div>
    );
  }

  const selectedParameter = selectedTab === 'all' ? undefined : selectedTab;

  return (
    <div className="min-h-screen bg-background">
      <DashboardHeader 
        lastUpdated={lastUpdated} 
        onRefresh={handleRefresh} 
        isLoading={isLoading} 
      />

      <div className="container max-w-screen-2xl mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <div className="lg:col-span-1 order-2 lg:order-1">
            <ThresholdPanel 
              thresholds={thresholds}
              onThresholdChange={handleThresholdChange}
            />
          </div>

          <div className="lg:col-span-3 order-1 lg:order-2">
            <ParameterTabs value={selectedTab} onValueChange={setSelectedTab}>
              <WeatherTable 
                data={processedData}
                thresholds={thresholds}
                selectedParameter={selectedParameter}
              />
            </ParameterTabs>
          </div>
        </div>
      </div>
    </div>
  );
}
