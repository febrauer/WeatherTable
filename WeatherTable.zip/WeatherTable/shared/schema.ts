import { z } from "zod";

// Weather parameter metadata
export const weatherParameters = [
  { key: 'temperature_2m', label: 'Temperature', unit: '°C', defaultMin: 0, defaultMax: 30 },
  { key: 'apparent_temperature', label: 'Feels Like', unit: '°C', defaultMin: 0, defaultMax: 30 },
  { key: 'relative_humidity_2m', label: 'Humidity', unit: '%', defaultMin: 30, defaultMax: 80 },
  { key: 'dew_point_2m', label: 'Dew Point', unit: '°C', defaultMin: -5, defaultMax: 20 },
  { key: 'precipitation', label: 'Precipitation', unit: 'mm', defaultMin: 0, defaultMax: 5 },
  { key: 'rain', label: 'Rain', unit: 'mm', defaultMin: 0, defaultMax: 5 },
  { key: 'showers', label: 'Showers', unit: 'mm', defaultMin: 0, defaultMax: 5 },
  { key: 'snowfall', label: 'Snowfall', unit: 'cm', defaultMin: 0, defaultMax: 2 },
  { key: 'hail', label: 'Hail', unit: 'mm', defaultMin: 0, defaultMax: 1 },
  { key: 'weather_code', label: 'Weather Code', unit: '', defaultMin: 0, defaultMax: 99 },
  { key: 'visibility', label: 'Visibility', unit: 'm', defaultMin: 1000, defaultMax: 50000 },
  { key: 'pressure_msl', label: 'Pressure', unit: 'hPa', defaultMin: 980, defaultMax: 1030 },
  { key: 'wind_speed_10m', label: 'Wind Speed', unit: 'km/h', defaultMin: 0, defaultMax: 50 },
  { key: 'wind_gusts_10m', label: 'Wind Gusts', unit: 'km/h', defaultMin: 0, defaultMax: 70 },
  { key: 'wind_direction_10m', label: 'Wind Direction', unit: '°', defaultMin: 0, defaultMax: 360 },
  { key: 'cloud_cover', label: 'Cloud Cover', unit: '%', defaultMin: 0, defaultMax: 100 },
] as const;

export type WeatherParameterKey = typeof weatherParameters[number]['key'];

// Open-Meteo API response schema
export const weatherDataSchema = z.object({
  hourly: z.object({
    time: z.array(z.string()),
    temperature_2m: z.array(z.number()).optional(),
    apparent_temperature: z.array(z.number()).optional(),
    relative_humidity_2m: z.array(z.number()).optional(),
    dew_point_2m: z.array(z.number()).optional(),
    precipitation: z.array(z.number()).optional(),
    rain: z.array(z.number()).optional(),
    showers: z.array(z.number()).optional(),
    snowfall: z.array(z.number()).optional(),
    hail: z.array(z.number()).optional(),
    weather_code: z.array(z.number()).optional(),
    visibility: z.array(z.number()).optional(),
    pressure_msl: z.array(z.number()).optional(),
    wind_speed_10m: z.array(z.number()).optional(),
    wind_gusts_10m: z.array(z.number()).optional(),
    wind_direction_10m: z.array(z.number()).optional(),
    cloud_cover: z.array(z.number()).optional(),
  }),
  hourly_units: z.record(z.string()).optional(),
});

export type WeatherData = z.infer<typeof weatherDataSchema>;

// Threshold configuration
export const thresholdSchema = z.object({
  parameter: z.string(),
  min: z.number().nullable(),
  max: z.number().nullable(),
});

export type Threshold = z.infer<typeof thresholdSchema>;

// Processed hourly data row
export interface HourlyDataRow {
  time: string;
  [key: string]: string | number | null;
}

// Threshold state for all parameters
export type ThresholdState = Record<string, { min: number | null; max: number | null }>;

// Location data
export interface Location {
  name: string;
  latitude: number;
  longitude: number;
  country?: string;
  state?: string;
}

// Nominatim API response
export const nominatimSearchSchema = z.object({
  place_id: z.number(),
  lat: z.string(),
  lon: z.string(),
  display_name: z.string(),
  address: z.object({
    city: z.string().optional(),
    town: z.string().optional(),
    village: z.string().optional(),
    state: z.string().optional(),
    country: z.string().optional(),
  }).optional(),
});

export type NominatimSearchResult = z.infer<typeof nominatimSearchSchema>;
