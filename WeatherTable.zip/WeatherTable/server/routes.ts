import type { Express } from "express";
import { createServer, type Server } from "http";

const OPEN_METEO_API_URL = "https://api.open-meteo.com/v1/forecast";
const LONDON_COORDS = {
  latitude: 51.5085,
  longitude: -0.1257,
};

export async function registerRoutes(app: Express): Promise<Server> {
  app.get("/api/weather", async (req, res) => {
    try {
      const params = new URLSearchParams({
        latitude: LONDON_COORDS.latitude.toString(),
        longitude: LONDON_COORDS.longitude.toString(),
        hourly: [
          'temperature_2m',
          'relative_humidity_2m',
          'dew_point_2m',
          'apparent_temperature',
          'precipitation',
          'rain',
          'showers',
          'snowfall',
          'hail',
          'weather_code',
          'visibility',
          'pressure_msl',
          'wind_speed_10m',
          'wind_gusts_10m',
          'wind_direction_10m',
          'cloud_cover',
        ].join(','),
        models: 'ukmo_global_deterministic_10km',
      });

      const response = await fetch(`${OPEN_METEO_API_URL}?${params.toString()}`);
      
      if (!response.ok) {
        throw new Error(`Open-Meteo API returned ${response.status}`);
      }

      const data = await response.json();
      res.json(data);
    } catch (error) {
      console.error('Error fetching weather data:', error);
      res.status(500).json({ 
        error: 'Failed to fetch weather data',
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
