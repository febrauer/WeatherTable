// No storage needed for this weather dashboard application
// All data is fetched from the Open-Meteo API in real-time

export interface IStorage {
  // No storage methods needed
}

export class MemStorage implements IStorage {
  constructor() {
    // No initialization needed
  }
}

export const storage = new MemStorage();
