# Weather Forecast Dashboard

## Overview
An interactive weather forecast dashboard that fetches hourly weather data from the Open-Meteo API for London, UK. The application displays multiple weather parameters in customizable tables with threshold-based highlighting to help users monitor conditions that exceed their specified ranges.

## Current State
- **Status**: MVP Complete
- **Last Updated**: October 23, 2025
- **Tech Stack**: React, TypeScript, Express, TailwindCSS, Shadcn UI

## Features
1. **Real-time Weather Data**: Fetches hourly forecast data from Open-Meteo API for London coordinates
2. **Interactive Tables**: Sortable, responsive tables displaying all weather parameters
3. **Threshold Controls**: Customizable min/max thresholds for each parameter
4. **Visual Highlighting**: Color-coded cells for values exceeding thresholds (red for high, blue for low)
5. **Parameter Tabs**: Switch between viewing all parameters or individual parameter details
6. **Dark/Light Mode**: Full theme support with automatic color adaptation
7. **Responsive Design**: Works across desktop, tablet, and mobile devices

## Project Architecture

### Frontend (`client/`)
- **Main Page**: `src/pages/dashboard.tsx` - Main dashboard with data fetching and state management
- **Components**:
  - `dashboard-header.tsx` - Header with location, refresh button, and theme toggle
  - `weather-table.tsx` - Interactive table with sorting and threshold highlighting
  - `threshold-panel.tsx` - Sidebar panel with all threshold controls
  - `threshold-control.tsx` - Individual parameter threshold input component
  - `parameter-tabs.tsx` - Tab system for parameter filtering
  - `loading-skeleton.tsx` - Loading state skeleton
  - `theme-toggle.tsx` - Light/dark mode toggle button
- **Lib**: `lib/theme-provider.tsx` - Theme context provider

### Backend (`server/`)
- **API Routes** (`routes.ts`): 
  - `GET /api/weather` - Proxies Open-Meteo API requests with London coordinates
- **Storage** (`storage.ts`): No persistent storage needed (real-time API data)

### Shared (`shared/`)
- **Schema** (`schema.ts`): TypeScript interfaces and Zod schemas for weather data

## Weather Parameters Monitored
1. Temperature (°C)
2. Feels Like/Apparent Temperature (°C)
3. Relative Humidity (%)
4. Dew Point (°C)
5. Precipitation (mm)
6. Rain (mm)
7. Showers (mm)
8. Snowfall (cm)
9. Hail (mm)
10. Weather Code
11. Visibility (m)
12. Pressure MSL (hPa)
13. Wind Speed (km/h)
14. Wind Gusts (km/h)
15. Wind Direction (°)
16. Cloud Cover (%)

## Design System
- **Colors**: Deep slate backgrounds in dark mode, subtle elevation-based surfaces
- **Typography**: Inter for UI, JetBrains Mono for data values
- **Spacing**: Consistent 6-8px spacing system
- **Components**: Shadcn UI with custom threshold highlighting
- **Interactions**: Hover elevations, smooth transitions, instant threshold updates

## API Integration
- **External API**: Open-Meteo Forecast API (https://api.open-meteo.com/v1/forecast)
- **Model**: UKMO Global Deterministic 10km
- **Location**: London, UK (51.5085°N, -0.1257°W)
- **No API Key Required**: Open-Meteo is a free, open API

## User Preferences
- Default theme: Dark mode
- Focus on data clarity and scannable tables
- Real-time threshold highlighting for quick anomaly detection
